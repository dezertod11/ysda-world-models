Primary: icra2027.tex (PaperCept IEEE ICRA, numeric citations).
Alternative: iclr2027.tex (ICLR 2027, author-year citations).
Edit paper.tex. Do not submit both simultaneously. Human author approval required.
Local: tectonic icra2027.tex or latexmk -pdf icra2027.tex.
Scientific validation and contributor raw-data audit are tracked outside this typesetting package.
