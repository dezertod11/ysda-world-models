ICLR 2027 manuscript, evidence snapshot 2026-09-14.
Main file: iclr2027.tex; edit main.tex.
Overleaf: upload this ZIP and select iclr2027.tex.
Local: latexmk -pdf iclr2027.tex, or tectonic iclr2027.tex.
Figures, tables, bibliography and official styles are included.
This is an anonymous working manuscript, not a submitted paper.
Human authors must review claims, references and AI-use disclosure before submission.
